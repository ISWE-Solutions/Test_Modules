## Module <project_dashboard_odoo>

#### 30.11.2023
#### Version 17.0.1.0.0
##### ADD

- Initial Commit for Project Dashboard
